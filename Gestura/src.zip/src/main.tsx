import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter as Router, Route, Route, Navigate } from 'react-router-dom';
import App from './App';
import Login from './Login';
import MainWindow from './Main-window';
import Register from './Register';

ReactDOM.createRoot(document.getElementById('root')!).render(
  <React.StrictMode>
    <Router>
      <Routes>
        {/* Redirect to Main-window instead of Login by default */}
        <Route path="/" element={<Navigate replace to="/main-window" />} />

        {/* Route for Main-window */}
        <Route path="/main-window" element={<MainWindow />} />

        {/* Other Routes */}
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/app" element={<App />} />
      </Routes> 
    </Router>
  </React.StrictMode>
);